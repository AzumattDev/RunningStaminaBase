> # Update Information (Latest listed first)
> ### v1.0.4
> - Ashlands Update
> ### v1.0.3
> - Update for Valheim 0.217.22
> ### v1.0.2
> - Default stamina is 50 in vanilla...code showed 75. Oh well, fixed.
> ### v1.0.1
> - Bug fix
> ### v1.0.0
> - Initial Release