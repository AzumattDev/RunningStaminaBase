# Description

## This mod will update your base stamina by a factor of your current running skill

`This mod is not needed on a server. It's client only. Install on each client that you wish to have the mod load.`

#### Incompatible Mod Information

* This mod will likely be slightly incompatible with any mod that modifies the base stamina value.

`Feel free to reach out to me on discord if you need manual download assistance.`

# Author Information

### Azumatt

`DISCORD:` Azumatt#2625

`STEAM:` https://steamcommunity.com/id/azumatt/

For Questions or Comments, find me in the Odin Plus Team Discord or in mine:

[![https://i.imgur.com/XXP6HCU.png](https://i.imgur.com/XXP6HCU.png)](https://discord.gg/Pb6bVMnFb2)
<a href="https://discord.gg/pdHgy6Bsng"><img src="https://i.imgur.com/Xlcbmm9.png" href="https://discord.gg/pdHgy6Bsng" width="175" height="175"></a>
***

> # Update Information (Latest listed first)
> ### v1.0.3
> - Update for Valheim 0.217.22
> ### v1.0.2
> - Default stamina is 50 in vanilla...code showed 75. Oh well, fixed.
> ### v1.0.1
> - Bug fix
> ### v1.0.0
> - Initial Release